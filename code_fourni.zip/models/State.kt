package ch.heigvd.iict.and.labo4.models

enum class State {
    IN_PROGRESS, DONE
}