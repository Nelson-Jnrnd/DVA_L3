package ch.heigvd.iict.and.labo4.models

enum class Type {
    NONE, TODO, SHOPPING, WORK, FAMILY
}